package com.example.Marketplace.Entity;

public enum Rol {
    COMPRADOR,
    VENDEDOR
}

