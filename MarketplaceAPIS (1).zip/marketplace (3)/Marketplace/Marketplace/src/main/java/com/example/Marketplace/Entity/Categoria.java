package com.example.Marketplace.Entity;

public enum Categoria {
    CONSOLAS,
    JUEGOS,
    ACCESORIOS,
    HARDWARE,
    OTROS
}
